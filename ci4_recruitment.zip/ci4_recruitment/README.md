# CodeIginter4 - Recruitment Site

## Software Needed
- XAMPP, WAMP, or any which has a PHP Version >= 8

Please Open your **XAMPP/WAMP's Control Panel** and start **Apache** and **MySQL**

## Instructions

1. Create new Database naming "recruitment_db"
2. Import the sql file located @ database directory
3. Browse the project in a Browser i.e. [http://localhost/ci4_recruitment]

## Admin Access

- **Email:** admin@mail.com
- **Password:** admin123

This demo source code was created by **oretnom23**