<?= $this->extend('layouts/vacancy_base') ?>
<?= $this->section('content') ?>
<div class="card rounded-0 shadow py-5">
    <div class="card-body">
        <div class="container-fluid">
            <h1 class="py-3">Page Not Found</h1>
        </div>
    </div>
</div>
<?= $this->endSection() ?>